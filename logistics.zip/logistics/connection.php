<?php
$host  = "localhost";
$username = "root"; // For MYSQL the predifined username is root
$password = ""; // For MYSQL the predifined password is " "(blank)
$db="logic_test";

// Create connection
$conn= new mysqli($host, $username, $password,$db);


 // Check connection

 if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}



?>