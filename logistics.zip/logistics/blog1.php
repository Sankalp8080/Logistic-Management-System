<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="js/message.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">



    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <style type="text/css">
      p{
        color: black;
      }
      #wel{
        color: white;
      }
    </style>
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-11 col-xl-2">
            <h1 class="mb-0"><a href="index1.php" class="text-white h2 mb-0">Logistics</a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              
                            <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                                <li class="active"><a href="index1.php">Home</a></li>
                                <li><a href="about1.php">About Us</a></li>
                                <li class="has-children">
                                    <a href="services1.php">Services</a>
                                    <ul class="dropdown">
                                        <li><a href="./comingsoon/index1.php">Air Freight</a></li>
                    <li><a href="./comingsoon/index1.php">Ocean Freight</a></li>
                    <li><a href="map.html">Ground Shipping</a></li>
                                    </ul>
                                </li>
                                <li><a href="industries1.php">Industries</a></li>
                                <li><a href="blog1.php">Blog</a></li>
                                <li><a href="contact1.php">Contact</a></li>
                                                              
                                 <label id="wel">
                                    <?php
                                session_start();
                                 echo "Welcome ".$_SESSION['email'];
                             ?> </label></li>
                             
                             <li><ul class="dropdown">
                                    <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                               </ul> </li>
                           </ul>
            </nav>
          </div>


          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
            <h1 class="text-white font-weight-light text-uppercase font-weight-bold">Our Blog</h1>
            <p class="breadcrumb-custom"><a href="index.html">Home</a> <span class="mx-2">&gt;</span> <span>Blog</span></p>
          </div>
        </div>
      </div>
    </div>  

    
  
    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_1.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://www.ccjdigital.com/business">Commercial Carrier Journal</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>Commercial Carrier Journal has not only an excellent blog, but also a very high-quality and informative newsletter. Most of CCJ’s blog posts are in some way related to trucking and commercial transportation, but they also cover relevant parallel topics such as infrastructure, big data and compliance, providing a more complete picture of current events in the industry.</p>
            </div> 
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_2.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://forto.com/en/blog/">Freight Hub</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>Freight Hub is a German freight forwarding company with a global reach. It’s blog is a refreshing assortment of internationally relevant content, ranging from discussions on regulation to case studies and exploration of new transportation and logistics technology. It’s a great resource for international shippers, but is equally helpful to understand the global climate around shipping, transportation and logistics.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_1.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://www.ibm.com/blogs/services/">IBM Travel and Transportation</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>From a data quality and comprehensiveness standpoint, there’s nothing out there quite like the IBM Travel and Transportation Industry Blog. It’s not all about commercial transportation and logistics, but the articles that are go into detail on blockchain technology and the Internet of Things, as well as important topics like regulation in the commercial transportation industry and advice for shippers. A must read.</p>
            </div> 
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_2.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://www.bulktransporter.com/">Bulk Transporter</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>Bulk Transporter offers a more general approach to discussing topics in the world of transportation. The blog covers areas like fleet management, government regulation and technology, but also dives into topics like green energy, fuel prices and safety. This is an excellent resource for quality content that spans the transportation industry as a whole.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_1.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://ngtnews.com/">NGT News</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>Next Generation Transportation (NGT) boasts exceptional content centered around alternative fuel and transportation. NGT’s blog serves primarily as a news source for all updates and important developments in the world of alternative energy as it pertains to transportation, and also discusses regulation and legislation surrounding the important topics in that sphere.</p>
            </div> 
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="h-entry">
              <img src="images/blog_2.jpg" alt="Image" class="img-fluid">
              <h2 class="font-size-regular"><a href="https://www.primemovermag.com.au/blog/">Prime Mover</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Oct 20, 2021<span class="mx-2">&bullet;</span> <a href="#">News</a></div>
              <p>Prime Mover is an Australian magazine that also boasts a great blog. The blog spans multiple categories, from industry news to driver safety. All articles are written by long-time industry experts who offer informed insights on global transportation news.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container text-center pb-5">
      <div class="row">
        <div class="col-12">
          <p class="custom-pagination">
            <span>1</span>
            <a href="#">2</a>
            <a href="#">3</a>
          </p>
        </div>
      </div>
    </div>

    
    
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Quick Links</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Products</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Follow Us</h2>
                            <a href="https://www.instagram.com/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                            <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4tZ2IifQ%3D%3D%22%7D" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                            <a href="https://www.facebook.com/" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                            <a href="https://www.linkedin.com/" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
                    <form action="#" method="post">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" id="sub" name="sub" aria-label="Enter Email" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary text-white " onclick="thank();" type="button" id="button-addon2">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row pt-5 mt-5 text-center">
                <div class="col-md-12">
                    <div class="border-top pt-5">
                        
                    </div>
                </div>

            </div>
        </div>
    </footer>

  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>