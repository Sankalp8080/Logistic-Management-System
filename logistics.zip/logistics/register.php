<?php
  include ('connection.php'); 
  $name = $_POST['username'];
  $email = $_POST['emailid'];
  $password = $_POST['pass'];
  $sql ="insert into registration(name,email,password) values('$name','$email','$password')";
 
$duplicate=mysqli_query($conn,"SELECT * FROM registration WHERE email='$email'");
   if(mysqli_num_rows($duplicate)>0){
        echo "<script>alert('This Email Id is Already Existed')</script>";
   }
   else{
 $result= mysqli_query($conn,$sql);
 
      echo "<script>alert('Your account for LMS is created successfully :)')</script>";
  echo "<script>window.open('login.html','_self')</script>";

         
     }
    
     ?>