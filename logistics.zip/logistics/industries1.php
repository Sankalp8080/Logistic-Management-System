<!DOCTYPE html>
<html lang="en">
  <head>
    <title>LMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">
<script src="js/message.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">



    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <style type="text/css">
      p{
        color: black;
      }
      #wel{
        color: white;
      }
    </style>
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-11 col-xl-2">
            <h1 class="mb-0"><a href="index1.php" class="text-white h2 mb-0">Logistics</a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

                            <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                                <li class="active"><a href="index1.php">Home</a></li>
                                <li><a href="about1.php">About Us</a></li>
                                <li class="has-children">
                                    <a href="services1.php">Services</a>
                                    <ul class="dropdown">
                                        <li><a href="./comingsoon/index1.php">Air Freight</a></li>
                    <li><a href="./comingsoon/index1.php">Ocean Freight</a></li>
                    <li><a href="map.html">Ground Shipping</a></li>
                                    </ul>
                                </li>
                                <li><a href="industries1.php">Industries</a></li>
                                <li><a href="blog1.php">Blog</a></li>
                                <li><a href="contact1.php">Contact</a></li>
                                                              
                                 <label id="wel">
                                    <?php
                                session_start();
                                 echo "Welcome ".$_SESSION['email'];
                             ?> </label></li>
                             
                             <li><ul class="dropdown">
                                    <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                               </ul> </li>
                           </ul>
            </nav>
          </div>


          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
            <h1 class="text-white font-weight-light text-uppercase font-weight-bold">Industries</h1>
            <p class="breadcrumb-custom"><a href="index.html">Home</a> <span class="mx-2">&gt;</span> <span>Industries</span></p>
          </div>
        </div>
      </div>
    </div>  

    
  
    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_1.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Storage</h3>
                <p class="px-5">Storage plays a vital part in the supply chain given that it helps to guarantee good delivery times and reduce warehouse losses, making it possible to offer better services, to occupy a position ahead of competitors and, ultimately, to increase profits.</p>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_2.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Air Transports</h3>
                <p class="px-5">The airport cargo services and airfreight industry are integral components in the overall logistics industry, which plays a supporting (but critical) function in bringing the cargoes from the airport to the recipients at different destinations (or from sources of productions to the airport)</p>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_3.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Cargo Transports</h3>
                <p class="px-5">Freight management logistics encompass the technology, experience, human resources and knowledge utilized to facilitate effective, efficient and expeditious coordination between carriers and shippers and ensure goods are delivered on budget, and on time.</p>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_4.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Cargo Ship</h3>
                <p class="px-5">Sea Freight is a method of transporting large amounts of goods using carrier ships. Goods are packed into containers and then loaded onto a vessel. A typical cargo ship can carry around 18,000 containers, which means that sea freight is a cost-efficient way to transport high quantities over large distances.</p>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_5.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Ware Housing</h3>
                <p class="px-5">Warehouse management system is important to handle the fluctuations in demand and supply and avoid losses. ... Effective WMS ensures improved inventory control and management, which means you can ensure the safety of the goods, avoid product spoilage or theft or an accident.</p>
              </div>
            </a>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <a href="#" class="unit-1 text-center">
              <img src="images/img_1.jpg" alt="Image" class="img-fluid">
              <div class="unit-1-text">
                <h3 class="unit-1-heading">Freight shipping</h3>
                <p class="px-5">Freight shipping is the transportation of goods, commodities and cargo in bulk by ship, aircraft, truck or intermodal via train and road. It can be transported domestically or internationally by land, air or sea.Transport logistics is an integral process of every business because it is needed in day to day operations.</p>
              </div>
            </a>
          </div>
          
        </div>
      </div>
    </div>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row align-items-stretch">
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-travel"></span></div>
              <div>
                <h3>Air Freight</h3>
                <p>Air freight is another term for air cargo that is, the shipment of goods through an air carrier. Air transport services are the most valuable when it comes to moving express shipments around the globe. </p>
                <p><a href="https://supremefreight.com/what-is-air-freight-logistics/">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-sea-ship-with-containers"></span></div>
              <div>
                <h3>Ocean Freight</h3>
                <p>Ocean freight, also called sea freight, is the movement of goods internationally by sea. Ocean freight is far and away the most popular option for shipping goods internationally.</p>
                <p><a href="https://seller.alibaba.com/businessblogs/px6pr5bh-what-is-ocean-freight-a-complete-guide">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-frontal-truck"></span></div>
              <div>
                <h3>Ground Shipping</h3>
                <p>Ground freight is a cheap freight transportation method and is generally used to transport large items that are not time-sensitive. shipping freight via ground requires an average transit time of three to 10 days, depending on the pickup and delivery locations.</p>
                <p><a href="https://www.freightcenter.com/ground-freight">Learn More</a></p>
              </div>
            </div>
          </div>


          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-barn"></span></div>
              <div>
                <h3>Warehousing</h3>
                <p>A WMS constitutes an internal system of the logistics companies, which is highly configurable to control and manage aspects of storage, distribution, others.</p>
                <p><a href="https://mobisoftinfotech.com/resources/blog/warehouse-management-system-role-and-functions-in-logistics-chain/">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-platform"></span></div>
              <div>
                <h3>Storage</h3>
                <p>Storage is the activity of storing products at warehouses and logistics centers. Its role is to provide a steady supply of goods to the market to fill the temporal gap between producers and consumers.</p>
                <p><a href="https://www.bilogistik.com/en/blog/importance-storage-logistics-chain/">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-car"></span></div>
              <div>
                <h3>Delivery Van</h3>
                <p>Logistics companies manage the entire flow of the delivery process including all of the warehouses, people and resources that are involved from the point of collection to the point of delivery.
                </p>
                <p><a href="https://www.scm-portal.net/glossary/delivery.shtml">Learn More</a></p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    
    
    
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Quick Links</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Products</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Follow Us</h2>
                            <a href="https://www.instagram.com/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                            <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4tZ2IifQ%3D%3D%22%7D" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                            <a href="https://www.facebook.com/" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                            <a href="https://www.linkedin.com/" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
                    <form action="#" method="post">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" id="sub" name="sub" aria-label="Enter Email" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary text-white " onclick="thank();" type="button" id="button-addon2">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row pt-5 mt-5 text-center">
                <div class="col-md-12">
                    <div class="border-top pt-5">
                        
                    </div>
                </div>

            </div>
        </div>
    </footer>

  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>