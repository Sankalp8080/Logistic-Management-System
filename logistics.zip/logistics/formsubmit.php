<?php
  include ('connection.php'); 
  include_once("./fpdf/fpdf.php");

$name = $_POST['txtFirstName']." ".$_POST['txtLastName'];

$phone = $_POST['txtMobileNo'];
$senderaddress = $_POST['txtSenderAddress'];
$receiveraddress = $_POST['txtReceiverAddress'];
$distance = $_POST['txtenterdistance'].' km';
$itemname = $_POST['txtItemname'];
$itemquantity = $_POST['txtItemquantity'];
$itemweight = $_POST['txtItemweight'];
$paymentmethod = $_POST['txtpayment'];

$sql ="insert into form(Name,Phoneno,Sender_Address,Receiver_Address,Distance,Item_Name,Item_Quantity,Item_weight,Payment_method) 
values('$name','$phone','$senderaddress','$receiveraddress','$distance','$itemname','$itemquantity','$itemweight','$paymentmethod')";
$result= mysqli_query($conn,$sql);

$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->setFont("Arial","B",16);
	$pdf->Cell(190,10,"Inventory System",0,1,"C");
	$pdf->setFont("Arial",null,12);
	$pdf->Cell(50,10,"Date",0,0);
	$pdf->Cell(50,10,": ".date("d/m/Y"),0,1);
	$pdf->Cell(50,10,"Customer Name",0,0);
	$pdf->Cell(50,10,": ".$name,0,1);

	$pdf->Cell(40,10,"",0,1);

	$pdf->Cell(10,10,"#",1,0,"C");
	$pdf->Cell(70,10,"Product Name",1,0,"C");
	$pdf->Cell(30,10,"Quantity",1,0,"C");
	$pdf->Cell(30,10,"Price by Miles ",1,0,"C");
    $pdf->Cell(30,10,"Price by Kg ",1,0,"C");
	$pdf->Cell(20,10,"Total (Rs)",1,1,"C");

	//for ($i=0; $i < count($_GET["pid"]) ; $i++) { 
		$pdf->Cell(10,10, (1) ,1,0,"C");
		$pdf->Cell(70,10, $itemname,1,0,"C");
		$pdf->Cell(30,10, $itemquantity,1,0,"C");
		$pdf->Cell(30,10, ((float)$distance * 35 ) ,1,0,"C");
        $pdf->Cell(30,10, ($itemweight * 5) ,1,0,"C");
		$pdf->Cell(20,10, ((float)$distance * 35 + $itemweight * 5) ,1,1,"C");
	//}

	$pdf->Cell(50,10,"",0,1);

	$pdf->Cell(50,10,"Final Total",0,0);
	$pdf->Cell(50,10,": Rs ".((float)$distance * 35 + $itemweight * 5+$itemquantity*10),0,1);
	//$pdf->Cell(50,10,"Tax",0,0);
	//$pdf->Cell(50,10,": Rs ".((float)$distance * 40 + $itemweight * 5),0,1);
	$pdf->Cell(50,10,"Payment Type",0,0);
	$pdf->Cell(50,10,": ".$paymentmethod,0,1);


	$pdf->Cell(180,10,"Signature",0,0,"R");


	$pdf->Output("./PDF_INVOICE/PDF_INVOICE_".$name.".pdf", "F");
	$pdf->Output();	

?>