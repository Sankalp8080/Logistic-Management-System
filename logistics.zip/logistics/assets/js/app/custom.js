var $ = jQuery.noConflict();

/*-------------------------------------------------*/
/* =  Application Global
/*-------------------------------------------------*/
var MESSAGE_TYPE =
    {
        'Success'   : 'success',
        'Info'      : 'info',
        'Warning'   : 'warning',
        'Danger'    : 'danger'
    };
var Application =
    {
        BaseUrl: ""
    };

Application.init = function () {    
    Config.init();
    //Config.Core.AvoidSubmitOnEnterKey();       
};

jQuery.fn.forceNumeric = function () {

    return this.each(function () {
        $(this).keydown(function (e) {
            var key = e.which || e.keyCode;

            if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
                // numbers   
                key >= 48 && key <= 57 ||
                // Numeric keypad
                key >= 96 && key <= 105 ||
                // comma, period and minus, . on keypad
               key == 110 ||
                // Backspace and Tab and Enter
               key == 8 || key == 9 || key == 13 ||
                // Home and End
               key == 35 || key == 36 ||
                // left and right arrows
               key == 37 || key == 39 ||
                // Del and Ins
               key == 46 || key == 45 || key==190)
                return true;

            return false;
        });
    });
}

/*-------------------------------------------------*/
/* =  Global Configuration
/*-------------------------------------------------*/
var Config = {};

Config.Core = {};

Config.Core.SetMenu = function (activeMenu, completedMenu, mainFormID) {
    
    if (mainFormID === 0) {
        $('#menu_' + completedMenu).addClass('complete');
        $('#menu_' + completedMenu).parent().prevAll('li').find('a').addClass('complete');
        $('#menu_' + completedMenu).closest('li').nextAll().addClass('disabled-link');
    } else {
        $('#topMain').find('a').addClass('complete');
    }

    $('#menu_' + activeMenu).removeClass('complete').addClass('active');

};


Config.Core.ResolveUrl = function (url) {
    if (url.indexOf("~/") === 0) {
        url = Application.BaseUrl + url.substring(2);
    }
    return url;
};

Config.Core.ScrollToError = function () {
    var element = document.getElementById('messageHolder');
    element.scrollIntoView();
    element.scrollIntoView(false);
    element.scrollIntoView({ block: "end" });
    element.scrollIntoView({ behaviour: "smooth", block: "end", inline: "nearest" });
}

Config.Core.ScrollToFirstError = function () {
    var element = document.querySelector('.has-error');
    element.scrollIntoView();
    element.scrollIntoView(false);
    element.scrollIntoView({ block: "end" });
    element.scrollIntoView({ behaviour: "smooth", block: "end", inline: "nearest" });
};

Config.Core.ShowResponsiveMessage = function (control, type, message) {
    var messageClass = "";
    switch (type.toLowerCase()) {
        case "alert":
            messageClass = "alert-warning";
            break;
        case "error":
            messageClass = "alert-danger";
            break;
        case "success":
            messageClass = "alert-success";
            break;
        default:
    }
    $("#" + control).show();
    $("#" + control).removeClass('hide');
    $("#" + control).html("<div class='alert " + messageClass + "'>&nbsp;" + message);
    //$("#" + control).animate({ scrollTop: $('#' + control).position().top }, 300);
    Config.Core.ScrollToError();
};

Config.Core.ShowMessage = function (control, type, message) {
    var messageClass = "";
    switch (type.toLowerCase()) {
        case "alert":
            messageClass = "alert-warning";
            break;
        case "error":
            messageClass = "alert-danger";
            break;
        case "success":
            messageClass = "alert-success";
            break;
        default:
    }
    $("#" + control).show();
    $("#" + control).removeClass('hide');
    $("#" + control).html("<div class='alert " + messageClass + "'><button type='button' class='close' data-dismiss='alert'><span>&times;</span></button><strong>" + type.toUpperCase() + " !</strong>&nbsp;" + message);    
};

Config.Core.ShowResponsiveProcessMessage = function (control) {
    //$('html, body').animate({ scrollTop: 0 }, 300);
    $("#" + control).animate({ scrollTop: $('#' + control).position().top }, 300);
    $("#" + control).show();
    $("#" + control).html("<div class='alert alert-info'><div id='ResponsiveProcessMessage'></div>");
    i = 0;
    text = "Please wait while your request is being processing ";
    setInterval(function () {
        $("#ResponsiveProcessMessage").html(text + Array((++i % 10) + 1).join("."));
    }, 500);
};
Config.Core.HideResponsiveMessage = function (control) {

    $("#" + control).empty();
    $("#" + control).hide();
};
Config.Core.ShowMessage = function (control, type, message) {
    var messageClass = "";
    switch (type.toLowerCase()) {
        case "info":
            messageClass = "alert-info";
            break;
        case "alert":
            messageClass = "alert-warning";
            break;
        case "error":
            messageClass = "alert-danger";
            break;
        case "success":
            messageClass = "alert-success";
            break;
        default:
    }
    $("#" + control).show();
    $("#" + control).html("<div class='alert " + messageClass + "'><button type='button' class='close' data-dismiss='alert'><span>&times;</span></button><strong>" + type.toUpperCase() + " !</strong>&nbsp;" + message);
};
Config.Core.ShowProcessMessage = function (control) {
    $("#" + control).show();
    $("#" + control).html("<div class='alert alert-info'><div id='ResponsiveProcessMessage'></div>");
    i = 0;
    text = "Please wait while your request is being processing";
    setInterval(function () {
        $("#ResponsiveProcessMessage").html(text + Array((++i % 10) + 1).join("."));
    }, 500);
};

Config.SUCCESS_RESPONSE = "success";
Config.ERROR_RESPONSE = "error";
Config.ERROR_ALERT = "alert";
Config.ERROR_LONG_MESSAGE = "Oops, something went wrong. Please try again.";


Config.Core.IsNumeric = function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    }
}

Config.Core.CheckPaggination = function (jqobj) {
    if (jQuery(jqobj + '>span').eq(0).length > 0 && jQuery(jqobj + '>span').eq(0).children().size() < 6)
        jQuery(jqobj).hide();
}

Config.Core.AvoidSubmitOnEnterKey = function () {
    $(window).keydown(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });
}

Config.Core.ShowGrowl = function (type, message) {
    var title, icon;

    switch (type) {
        case 'success':
            title   = 'Success';
            icon    = 'fa fa-check-circle';
            break;
        case 'info':
            title   = 'Info';
            icon    = 'fa fa-info-circle';
            break;
        case 'warning':
            title   = 'Warning';
            icon    = 'fa fa-exclamation-triangle';
            break;
        case 'danger':
            title   = 'Danger';
            icon    = 'fa fa-times-circle';
            break;
        default:
            title   = '';
            icon    = '';

    }

    $.growl({
        icon    : icon,
        title   :  title + " : ",
        message : message
    },{
        type: type,
        placement: {
            from: "bottom",
            align: "left"
        },
        animate: {
            enter: 'animated fadeInLeft',
            exit: 'animated fadeOutLeft'
        }
    });

}

Config.Core.StringIsBlank = function (stringVal) {
    if (stringVal == null)
        return false;

    if (stringVal == 'null')
        return false;

    if (stringVal == undefined)
        return false;

    if (stringVal == 'undefined')
        return false;

    if ($.trim(stringVal).length > 0)
        return false;
    else
        return true;
}

Config.Core.ValidateEmail = function (email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

Config.Core.executeFunctionByName = function (functionName, context /*, args */) {
    var args = Array.prototype.slice.call(arguments, 2);
    var namespaces = functionName.split(".");
    var func = namespaces.pop();
    for (var i = 0; i < namespaces.length; i++) {
        context = context[namespaces[i]];
    }
    return context[func].apply(this, args);
}

Config.Core.replaceQueryStringParam = function (key, value) {
    var pathname = window.location.pathname;
    var params = Config.Core.toQueryStringParams(window.location.search);
    params[key] = value;

    return pathname + "?" + jQuery.param(params)
}

Config.Core.toQueryStringParams = function (searchUrl) {
    var result = {}
    if (searchUrl == '')
        return result;

    var queryString = searchUrl.substr(1);

    var params = queryString.split("&");

    jQuery.each(params, function (index, param) {
        var keyPair = param.split("=");

        var key = keyPair[0];
        var value = keyPair[1];

        if (result[key] == undefined)
            result[key] = value
        else {

            if (result[key] instanceof Array) //current var is an array just push another to it
                result[key].push(value)
            else { //duplicate var, then it must store as an array
                result[key] = [result[key]]
                result[key].push(value)
            }
        }
    })

    return result;
}

Config.init = function () {}

$(document).ready(function($) {
	"use strict";	
	
	Application.init();
	
    /*-------------------------------------------------*/
    /* =  Breadcrumb
    /*-------------------------------------------------*/
	var parentBreadcrumb    = $('.breadcrumb');
	var lastChildBreadcrumb = $('.breadcrumb li:last-child');
	var lastTextBreadcrumb = lastChildBreadcrumb.find('a').text().trim();
	lastChildBreadcrumb.remove();
	parentBreadcrumb.append(' <li class="active">' + lastTextBreadcrumb + '</li>');

});

/* Growl Message Pluging */
(function (jQuery) {
    jQuery.msgGrowl = function (config) {

        var defaults, options, container, msgGrowl, content, title, text, close;

        defaults = {
            type: ''
            , title: ''
            , text: ''
            , lifetime: 6500
            , sticky: false
            , position: 'bottom-right'
            , closeTrigger: true
            , onOpen: function () { }
            , onClose: function () { }
        };

        options = jQuery.extend(defaults, config);

        container = jQuery('.msgGrowl-container.' + options.position);

        if (!container.length) {
            container = jQuery('<div>', {
                'class': 'msgGrowl-container ' + options.position
            }).appendTo('body');
        }

        msgGrowl = jQuery('<div>', {
            'class': 'msgGrowl ' + options.type
        });

        content = jQuery('<div>', {
            'class': 'msgGrowl-content'
        }).appendTo(msgGrowl);

        text = jQuery('<span>', {
            text: options.text
        }).appendTo(content);

        if (options.closeTrigger) {
            close = jQuery('<div>', {
                'class': 'msgGrowl-close'
                , 'click': function (e) {
                    e.preventDefault();
                    jQuery(this).parent().fadeOut('medium', function () {
                        jQuery(this).remove();
                        if (typeof options.onClose === 'function') {
                            options.onClose();
                        }
                    });
                }
            }).appendTo(msgGrowl);
        }

        if (options.title != '') {
            title = jQuery('<h4>', {
                text: options.title
            }).prependTo(content);
        }

        if (options.lifetime > 0 && !options.sticky) {
            setTimeout(function () {
                if (typeof options.onClose === 'function') {
                    options.onClose();
                }
                msgGrowl.fadeOut('medium', function () { jQuery(this).remove(); });
            }, options.lifetime);
        }

        container.addClass(options.position);

        if (options.position.split('-')[0] === 'top') {
            msgGrowl.prependTo(container).hide().fadeIn('slow');
        } else {
            msgGrowl.appendTo(container).hide().fadeIn('slow');
        }

        if (typeof options.onOpen === 'function') {
            options.onOpen();
        }
    };
})(jQuery);
/* Growl Message Pluging */

var Helper = {};

Helper.fillDefaults = function (list, selectable) {
    
    // TODO: fill the default option in dropdown
    // selectable: pass false if making -- Select -- option selectable

    $.each(list, function (i, el) {
        var ddl = $(el);
        ddl.empty();

        if (selectable === undefined) {
            ddl.append($('<option/>', {
                value: "",
                html: '---- Select ----',
                selected: "selected",
                disabled: "disabled"
            }));
        }
        else {
            if (selectable === true) {
                ddl.append($('<option/>', {
                    value: "",
                    html: '---- Select ----',
                }));
            } else {
                ddl.append($('<option/>', {
                    value: "",
                    html: "",
                }));
            }
        }

        $(ddl).trigger("chosen:updated");
    });
}

Helper.fillSelect = function (name, dataSource, isObject, data, defaultValue) {

    // TODO: fill the specific options in dropdown

    // undefined data attribute array will be empty
    data = (data === undefined) ? [] : data;

    var ddl = $(name);
    $.each(dataSource, function (index, element) {

        if (isObject) {

            // when value is an object

            if (data.length == 0) {

                // without any data attributes

                ddl.append($('<option/>', {
                    value: element.ID,
                    html: element.Name
                }));
            }
            else {

                // with data attributes

                var object = {
                    value: element.ID,
                    html: element.Name
                };

                for (var i = 0; i < data.length; i++) {
                    object["data-" + data[i].toLowerCase()] = element[data[i]];
                }

                ddl.append($('<option/>', object));
            }
        }
        else {

            // when value is an element

            if (data.length == 0) {

                // without any data attributes

                ddl.append($('<option/>', {
                    value: element,
                    html: element
                }));
            }
            else {

                // with data attributes

                var object = {
                    value: element,
                    html: element
                };

                for (var i = 0; i < data.length; i++) {
                    object["data-" + data[i].toLowerCase()] = element[data[i]];
                }

                ddl.append($('<option/>', object));
            }
        }

    });

    // set default value of ddl if any
    if (!(defaultValue === undefined)) {
        $(ddl).val(defaultValue);
    }

    $(ddl).trigger("chosen:updated");
}

Helper.chosenInit = function (width) {

    if (width === undefined) {

        $('.chosen-select').chosen({ allow_single_deselect: true });
        $(window).off('resize.chosen').on('resize.chosen', function () {
            $('.chosen-select').each(function () {
                var $this = $(this);
                $this.next().css({ 'width': '85%' });
            });
        }).trigger('resize.chosen');
        $(document).on('settings.ace.chosen', function (e, event_name, event_val) {
            if (event_name !== 'sidebar_collapsed') return;
            $('.chosen-select').each(function () {
                var $this = $(this);
                $this.next().css({ 'width': '85%' });
            });
        });
    }
    else {
        $('.chosen-select').chosen({ allow_single_deselect: true });
        $(window).off('resize.chosen').on('resize.chosen', function () {
            $('.chosen-select').each(function () {
                var $this = $(this);
                $this.next().css({ 'width': width + 'px' });
            });
        }).trigger('resize.chosen');
        $(document).on('settings.ace.chosen', function (e, event_name, event_val) {
            if (event_name !== 'sidebar_collapsed') return;
            $('.chosen-select').each(function () {
                var $this = $(this);
                $this.next().css({ 'width': width + 'px' });
            });
        });
    }
}

Helper.emptySelect = function (control) {
    $(control)
        .find('option')
        .remove()
        .end()
        ;
}