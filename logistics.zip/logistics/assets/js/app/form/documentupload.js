$(function () {

    $("#divForm").hide();
    var DTO = {
        'ProfileID': ProfileID,
        'FormID': FormID,
        'MapCoID': MapCoId,
        'AcademicYearId': AcademicYearId,
        'CategoryQuotaIniId': CategoryQuotaIniId,
        'ProcessId': ProcessId,
        'CurrentURL': CurrentURL

    };
    
    $.ajax({
        type: "POST",
        url: BaseURL + '/PreAdmissionForm/DocumentUpload.aspx/GetDocumentsToBeSubmitted',
        data: JSON.stringify(DTO),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        beforeSend: function () {

         
        },
        success: function (response) {
            $("#divForm").show();

            var data = JSON.parse(response.d);
            PageData = data;


            init();

            eventAttachments();
            $("#loader").fadeOut("slow");
        }

    });

});

// Base Methods        
// ------------------------------------------------------------------------------------------
function init() {

    if (PageData.AlertType === "ERROR") {
        Config.Core.ScrollToError();
        Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Please follow the tab sequence.');
    }

	if(MapCoId==776){
		$("#hard_copy_container").hide();
	}

    if (MapCoId === "715") {
        $("#btnSubmit").text("Submit");
        $(".program-heading").remove();
    }

    Config.Core.ShowResponsiveProcessMessage('messageHolder');
    if (PageData.Content !== null) {
        $("#lblInstName").text(PageData.Content.Inst_Name);
        $("#lblCourseName").text(PageData.Content.Course_Name);
        $("#lblcategory").text(PageData.Content.Category_Name);
        $("#lblAppNo").text(PageData.Content.Bscil_Pre_Admn_Form_No);
        if (PageData.Content.Form_Content_Data !== null) {
            $('#notes_container').html(PageData.Content.Form_Content_Data);
        } else {
            $(".note_wrap").hide();
        }

	$("#sksasc").hide();
        $("#engg").hide();
	$("#simsr").hide();
	$("#nursing").hide();
 	if (PageData.Content.Inst_Name.trim() === "S K Somaiya College") {
            $("#sksasc").show();
            $("#engg").hide();
	    $("#simsr").hide();

		if(MapCoId==789 || MapCoId==790 || MapCoId==791 || MapCoId==792 || MapCoId==793 || MapCoId==794 || MapCoId==796 || MapCoId==798 || MapCoId==799 || MapCoId==800 || MapCoId==801 || MapCoId==802 || MapCoId==805 || MapCoId==806|| MapCoId==807)
		{
			//$("#lnkSKS").href('https://sksac.s3.ap-south-1.amazonaws.com/SKSC_DocumentsRequired(210420).pdf')
			  $("#lnkSKS").attr("href", 'https://sksac.s3.ap-south-1.amazonaws.com/SKSC_DocumentsRequired(210420).pdf');

		}
	
        } else {
            {
               
		if(MapCoId ==808){
		  $("#sksasc").hide();
                  $("#engg").show();
		  $("#lnkEngg").attr("href", 'https://kjsce.s3.ap-south-1.amazonaws.com/mtech/Documents+Required+-+as+per+guidelines.pdf');	
		}else if(MapCoId ==825){
 		  $("#engg").hide();
  		  $("#sksasc").hide();
		  $("#simsr").show();		
		}else if(MapCoId ==262){
 		  $("#engg").hide();
  		  $("#sksasc").hide();
		  $("#simsr").hide();	
		  $("#nursing").show();		
		}
            }
        }

    } else {
        $(".note_wrap").hide();
    }

    if (PageData.MenuList.length > 0) {
        renderFormMenu();
    }

    checkFormValidation();

    //renderHardCopyDocuments();
    renderDocumentControl().done(renderUploader());

    Config.Core.HideResponsiveMessage('messageHolder');

}

function checkFormValidation() {
    //Validation need to check if Date of Submission is passed
}

function eventAttachments() {

    $("#btnSubmit").click(function () {
        if (validateForm()) {
            postDocument();
        }
    });

    $("#btnPrevious").click(function () {
        location.href = BaseURL + PageData.Content.Previous_URL;
    });

    $('body').on('click', '.delete-dynamic-row', function () {
        removeRow($(this));
    });
}

// Render Methods        
// ------------------------------------------------------------------------------------------
function renderFormMenu() {
    $("#topMain").html("");
    PageData.MenuList.forEach(function (item, index) {
        var aclass = "";
        if (item.Is_Menu_Active === "Y") {
            aclass = "complete";
        } else {
            aclass = "disabled-link";
        }

        var li = `  <li class="nav-item pageLink">
                       <a id="menu_Instructions" class="nav-link ${aclass}" href="${BaseURL + item.Menu_Url}">
                        <span class="numb">${index + 1}</span><span class="page">${item.Admn_Form_Control_Name}</span></a></li>`;

        $('#topMain').append(li);

    });
    var pathname = window.location.href;

    $("#topMain").each(function () {
        $(this).find('a[href="' + pathname + '"]').removeClass('complete').addClass('active');
    });
}

function renderHardCopyDocuments() {
    const hardCopyList = PageData.HardCopyDocument;
    if (hardCopyList.length === 0) {
        $('#hard_copy_container').remove();
        return;
    }

    var html = '';

    const documentTypeList = removeDuplicates(PageData.HardCopyDocument, "Document_Type_Id");

    documentTypeList.forEach(function (item, index) {

        const documentList = PageData.HardCopyDocument.filter(i => i.Document_Type_Id === item.Document_Type_Id);

        documentList.forEach(function (document, index) {
            html = html + '<tr>';

            if (index === 0) {
                html = html + `
                        <th
                            rowspan="${documentList.length}"
                            class="talebg-grey table-border-right">
                                ${item.Document_Type_Name}<br/>
                                <span class="small-red">(${item.Any_One_Or_All})</span>
                        </th>`;
            }

            html = html + `
                    <td class="talebg-grey table-border-left">${document.Document_Name}<span style="color: red;">${(document.Is_Compulsory === 'Y' ? '  *' : '')}</span></td>
                    <td class="talebg-grey table-border-left">${item.Original_Attested}</td>
            `;

            html = html + '</tr>';
        });

    });
    
    $('#tblHardCopy tbody').append(html);
}

function renderDocumentControl() {
    var r = $.Deferred();

    const documentTypeList = removeDuplicates(PageData.SoftCopyDocument, "soft_doc_ini_id");

    var html = '';

    html = html + '<table class="table table-striped dashboard-table doc_upload-table">';
    html = html + '<tbody>';

    documentTypeList.forEach(function (item, index) {

        const documentList = PageData.SoftCopyDocument.filter(i => i.soft_doc_ini_id === item.soft_doc_ini_id);

        documentList.forEach(function (document, index) {

            html = html + '<tr>';

            if (index === 0) {
                html = html + `
                        <th
                            rowspan="${documentList.length}"
                            class="table-border-right document_type first"
                            data-document_type_id="${item.document_type_id}" 
                            data-any_one_or_all="${item.any_one_or_all}" 
                            data-soft_doc_ini_id="${item.soft_doc_ini_id}">
                                ${item.document_type_name}<br/>
                                <span class="small-red">(${item.any_one_or_all_text})</span>
                        </th>`;
            }

            html = html + `
                                <td class="talebg-grey second"
                                    data-document_id="${document.document_id}"
                                    data-is_this_doc_mandatory="${document.is_this_doc_mandatory}">
                                    ${document.document_name}<span style="color: red;">${(document.is_this_doc_mandatory === 'Y' ? '*' : '')}</span>
                                </td>`;

          if (document.document_varification_status === "VERIFIED") {
                html = html + ` 
                                <td class="talebg-grey table-border-left third">
                                    <div class="">
                                       
                                        <div class="file_container" id="file_container_${document.soft_doc_ini_id}_${document.document_type_id}_${document.document_id}">
                                            ${addRow(
                                                BASE.Settings.S3BucketsURL + '/documents/' + document.document_file_name,
                                                         document.document_file_name,
                                                document.softcopy_doc_tran_id, document.document_varification_status, document.remarks)
                    }
                                        </div>
                                    </div>
                                </td>
                                `;
            } else {
                html = html + ` 
                                <td class="talebg-grey table-border-left third">
                                    <div class="">
                                        <div class="file_uploader" 
                                            id="file_uploader_${document.soft_doc_ini_id}_${document.document_type_id}_${document.document_id}"
                                            data-uploader_soft_doc_ini_id="${document.soft_doc_ini_id}"
                                            data-uploader_document_type_id="${document.document_type_id}"
                                            data-uploader_document_id="${document.document_id}"
					    data-uploader_document_group_Id="${document.document_group_Id}"
                                            class="custom_file-upload file_uploader">
					                    </div>
                                        <div class="file_container" id="file_container_${document.soft_doc_ini_id}_${document.document_type_id}_${document.document_id}">
                                            ${addRow(
                    BASE.Settings.S3BucketsURL + '/documents/' + document.document_file_name,
                    document.document_file_name,document.softcopy_doc_tran_id, document.document_varification_status, document.remarks)
                    }
                                        </div>
                                    </div>
                                </td>
                                `;
            }

            html = html + '</tr>';

        });//documentList END

        
    });//documentTypeList END

    html = html + '</tbody>';
    html = html + '</table>';

    $('#document_upload_container').append(html);

    return r;
}

function renderUploader() {
    var r = $.Deferred();

    $(".file_uploader").each(function (index, listItem) {

        const element = $(this).data("uploader_soft_doc_ini_id") + "_" + $(this).data('uploader_document_type_id') + "_" + $(this).data("uploader_document_id");

        var uploader = new qq.FileUploader({
            element         : document.getElementById('file_uploader_' + element),
            action          : BaseURL + 'DocumentUpload/fileupload.ashx',
            params          : { FormID: FormID },
            multiple        : true,
            allowedExtensions: ['jpeg', 'jpg', 'png', 'pdf'],
            sizeLimit       : 1000000,
            showMessage     : function (message) {
                Config.Core.ShowResponsiveMessage('messageHolder', 'error', message);
                Config.Core.ScrollToError();
            },
            onComplete      : function (id, fileName, responseJSON) {
                if (responseJSON.success) {

                    const path = BASE.Settings.S3BucketsURL + '/documents/' + responseJSON.name;
                    
                    $('#file_container_' + element).append(addRow(path, responseJSON.name, 0));

                    const e = $('#file_uploader_' + element);

                    const data = {
                        PRE_ADMN_SOFTCOPY_DOC_TRAN_ID   : 0,
                        CLASS_SOFT_DOC_INI_ID           : $(e).data('uploader_soft_doc_ini_id'),
                        CATEGORY_SOFT_DOC_INI_ID        : 0,
                        QUAL_SOFT_DOC_INI_ID            : 0,
                        DOCUMENT_TYPE_ID                : $(e).data('uploader_document_type_id'),
                        DOCUMENT_ID                     : $(e).data('uploader_document_id'),
                        DOCUMENT_FILE_NAME              : responseJSON.name,
	 		DOCUMENT_GROUP_ID		: $(e).data('uploader_document_group_id'),
                        ACTION                          : 'I'
                    };
console.log( $(e).data('uploader_document_group_id'))
                    postSaveFile(data, '#file_container_' + element);
                    Config.Core.HideResponsiveMessage('messageHolder');
                }
                else {
                    Config.Core.ShowResponsiveMessage('messageHolder', 'error', responseJSON.message);
                    Config.Core.ScrollToError();
                }
            }
        });

    });

    return r;
}

function addRow(filePath, fileName, id,verificationStatus,remark) {
    var html = '';
    if (fileName) {
       if (verificationStatus === "VERIFIED") {
            html = `
            <div class="fullwidth file_holder">
			    <a href="${filePath}" target="_blank">${fileName}</a>
			    <div class="width-50">
				    <img src="${BaseURL + '/assets/img/chk.png'}" class="file-chk" />
                    
			    </div>
		    </div>
        `;
        } 
	else if (verificationStatus === "REJECTED") {
            html = `
            <div class="fullwidth file_holder">
			    <a href="${filePath}" target="_blank">${fileName}</a>
			    <div class="width-50" style="line-height:10px">
				   
                    <i class="fa fa-trash-o text-red del-t delete-dynamic-row" style="cursor: pointer;" aria-hidden="true" data-delete_softcopy_doc_tran_id="${id}"  ></i>
                    <span style="font-size: 10px;color: red;">Rejected Reason : ${remark}</span>
			    </div>
		    </div>
        `;
        }
	else {
            html = `
            <div class="fullwidth file_holder">
			    <a href="${filePath}" target="_blank">${fileName}</a>
			    <div class="width-50">
				    <img src="${BaseURL + '/assets/img/chk.png'}" class="file-chk" />
                    <i class="fa fa-trash-o text-red del-t delete-dynamic-row" aria-hidden="true" data-delete_softcopy_doc_tran_id="${id}" style="cursor: pointer;"  ></i>
			    </div>
		    </div>
        `;
        }
    }

    return html;
}

function removeRow(e) {
    
    const id = parseInt($(e).data('delete_softcopy_doc_tran_id'));

    if (id === 0) {
        Config.Core.ScrollToError();
        Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Error occured while deleting file.');
        return;
    }

    var document = PageData.SoftCopyDocument.find(i => i.softcopy_doc_tran_id === id);
    if (document === undefined) {
        const eleArr = $(e).parent().parent().parent().attr('id').split('_');
        document = {
            soft_doc_ini_id     : eleArr[2],
            document_type_id    : eleArr[3],
            document_id         : eleArr[4]
        };
    }

    const data = {
        PRE_ADMN_SOFTCOPY_DOC_TRAN_ID       : id,
        CLASS_SOFT_DOC_INI_ID               : document.soft_doc_ini_id,
        CATEGORY_SOFT_DOC_INI_ID            : 0,
        QUAL_SOFT_DOC_INI_ID                : 0,
        CRITERIA_SOFT_DOC_INI_ID            : document.soft_doc_ini_id,
        DOCUMENT_TYPE_ID                    : document.document_type_id,
        DOCUMENT_ID                         : document.document_id,
        DOCUMENT_FILE_NAME                  : $(e).find('a').text(),
        ACTION                              : 'D',
  	DOCUMENT_GROUP_ID 		    : 0,
    };
    postSaveFile(data);

    $(e).parent().parent().css("background-color", "#FF3700");
    $(e).parent().parent().fadeOut(400, function () {
        $(e).parent().parent().remove();
    });
}

// Helpers Methods        
// ------------------------------------------------------------------------------------------
function removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
        return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
}

function validateForm() {
    var isFormValid = false;

    var mandatoryDocCount = 0;

    $('.doc_upload-table > tbody  > tr').each(function () {
        const nameTD = $(this).find("[data-is_this_doc_mandatory='Y']");
        if ($(nameTD).length > 0) {
            if ($(this).find(':last-child').find('[id^=file_container_]').find('.file_holder').length === 0) {
                $(nameTD).addClass('red-text');
                mandatoryDocCount++;
            } else {
                $(nameTD).removeClass('red-text');
            }
        }
    });

    if (mandatoryDocCount > 0) {
        Config.Core.ScrollToError();
        Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Upload all the documents marked with * ');
    } else {
        isFormValid = true;
    }

    if (isFormValid) {
        $('.doc_upload-table > tbody  > tr').each(function () {
            const validationType = $(this).find(':first-child').data("any_one_or_all");
            if (validationType === 'ANYONE') {

                var documentUploadCount = 0;
                const soft_doc_ini_id = $(this).find(':first-child').data("soft_doc_ini_id");
                const document_type_id = $(this).find(':first-child').data("document_type_id");

                $('#document_upload_container').find(`[id^='file_container_${soft_doc_ini_id}_${document_type_id}_']`).each(function () {
                    documentUploadCount = documentUploadCount + $(this).find('.file_holder').length;
                });

                if (documentUploadCount === 0) {

                    const document_type = PageData.SoftCopyDocument.find(i => i.document_type_id === document_type_id);

                    Config.Core.ScrollToError();
                    Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Upload any one document for ' + document_type.document_type_name);
                    isFormValid = false;
                    return;
                }

            }
        });
    }


    return isFormValid;
}

// Post Methods        
// ------------------------------------------------------------------------------------------
function postSaveFile(data, tableID) {

console.log(data.DOCUMENT_GROUP_ID);

    var docDTO = {};

    docDTO.softcopy_doc_tran_id     = data.PRE_ADMN_SOFTCOPY_DOC_TRAN_ID;
    docDTO.bscil_pre_admn_form_no   = FormID;
    docDTO.soft_doc_ini_id          = data.CLASS_SOFT_DOC_INI_ID;
    docDTO.document_type_id         = data.DOCUMENT_TYPE_ID;
    docDTO.document_id              = data.DOCUMENT_ID;
    docDTO.document_file_name       = data.DOCUMENT_FILE_NAME;
    docDTO.TranType                 = data.ACTION;
    docDTO.document_group_Id        = data.DOCUMENT_GROUP_ID;
    var DTO = {
        'ProfileID'         : ProfileID,
        'FormID'            : FormID,
        'CategoryQuotaIniId': CategoryQuotaIniId,
        'MapCoID'           : MapCoId,
        'ProcessId'         : ProcessId,
        'NextURL'           : 'online-form/payment',
        'docDTO'            : docDTO,
	'AcademicYearId'    : AcademicYearId
    };

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: BaseURL + "/PreAdmissionForm/DocumentUpload.aspx/SaveDocument",
        data: JSON.stringify(DTO),
        dataType: "json",
        beforeSend: function () {
            Config.Core.ShowResponsiveProcessMessage('messageHolder');
        },
        success: function (result) {
            var data = JSON.parse(result.d);
            
            if (data.AlertType === 'SUCCESS') {
                Config.Core.HideResponsiveMessage('messageHolder');
               
                if (docDTO.TranType === 'I') {
                    const id = data.ID;
                    $(`${tableID}:last`).find('.delete-dynamic-row').attr('data-delete_softcopy_doc_tran_id', id);
                }
               
            } else {
		$("#file_container_" + docDTO.soft_doc_ini_id + "_" + docDTO.document_type_id + "_" + docDTO.document_id).remove();
                Config.Core.ScrollToError();
                Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Oops! Something went wrong! Help us improve your experience by sending an <a href="' + BaseURL + 'online-form/report-issue" target="_blank"> issue. </a>');
            }
        },
        error: function (result) {
            Config.Core.ScrollToError();
            Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Oops! Something went wrong! Help us improve your experience by sending an <a href="' + BaseURL + 'online-form/report-issue" target="_blank"> issue. </a>');
        }
    });
}

function postDocument() {

    var DTO = {
        'ProfileID': ProfileID,
        'FormID': FormID,
        'CategoryQuotaIniId': CategoryQuotaIniId,
        'MapCoID': MapCoId,
        'ProcessId': ProcessId,
        'NextURL': PageData.Content.Next_URL,
        'docDTO' :null,
        'AcademicYearId': AcademicYearId
    };

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: BaseURL + "/PreAdmissionForm/DocumentUpload.aspx/SubmitDocumentsSaveContinue",
        data: JSON.stringify(DTO),
        dataType: "json",
        beforeSend: function () {
            Config.Core.ShowResponsiveProcessMessage('messageHolder');
	    Config.Core.ScrollToError();
        },
        success: function (result) {

            var data = JSON.parse(result.d);

            if (data.AlertType === 'SUCCESS') {
                Config.Core.ShowResponsiveMessage('messageHolder', 'Success', "Details saved successfully. ");
                location.href = BaseURL + PageData.Content.Next_URL;
            }
            else if (data.AlertType === 'WARNING') {
                Config.Core.ScrollToError();
                Config.Core.ShowResponsiveMessage('messageHolder', 'alert', data.Message);
            }
            else {
                Config.Core.ScrollToError();
                Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Oops! Something went wrong! Help us improve your experience by sending an <a href="' + BaseURL + 'online-form/report-issue" target="_blank"> issue. </a>');
            }
        },
        error: function (result) {
            Config.Core.ScrollToError();
            Config.Core.ShowResponsiveMessage('messageHolder', 'Error', 'Oops! Something went wrong! Help us improve your experience by sending an <a href="' + BaseURL + 'online-form/report-issue" target="_blank"> issue. </a>');
        }
    });
}