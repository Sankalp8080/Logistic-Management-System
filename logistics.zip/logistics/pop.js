function mypop() {
    alert("Response has been Recorded");
    window.open('contact.html')
}

function wrongpop() {
    alert("Something Went wrong!!!")
}