   function show_message()
    {
        var uname=document.getElementById('uname').value;
        alert(uname +" Your Quote has been collected");

    }
    function thank()
    {
        var sub=document.getElementById('sub').value;
        alert("Thank You for subscribing !!!  "+sub);
    }
    var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
// Select all input elements for varification
const username = document.getElementById("username");
const emailid = document.getElementById("emailid");
const pass = document.getElementById("pass");

// function for form varification
function formValidation() {
  // checking length of name
  if (username.value.length < 6 || username.value.length > 20) {
    alert("Name length should be more than 6 and less than 21 charaters");
    username.focus();
    return false;
  }
  // checking email format
  if (emailid.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
    alert("Please enter a valid email!");
    emailid.focus();
    return false;
  }
  // checking password character pattern
  if (pass.value.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/)) {
    alert("Password must contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character, and must be between 8 and 15 characters long.");
    pass.focus();
    return false;
  }

  return true;
}