<!DOCTYPE html>
<html lang="en">

<head>
    <title>Logistics Management system  </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
<script src="js/message.js"></script>
<style type="text/css">
      p{
        color: black;
      }
      #wel{
        color: white;
      }
    </style>
</head>

<body>

    <div class="site-wrap">

        <div class="site-mobile-menu">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>

        <header class="site-navbar py-3" role="banner">

            <div class="container">
                <div class="row align-items-center">

                    <div class="col-11 col-xl-2">
                        <h1 class="mb-0"><a href="index1.php" class="text-white h2 mb-0">Logistics</a></h1>
                    </div>
                    <div class="col-12 col-md-10 d-none d-xl-block">
                        <nav class="site-navigation position-relative text-right" role="navigation">

                            <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                                <li class="active"><a href="index1.php">Home</a></li>
                                <li><a href="about1.php">About Us</a></li>
                                <li class="has-children">
                                    <a href="services1.php">Services</a>
                                    <ul class="dropdown">
                                        <li><a href="./comingsoon/index1.php">Air Freight</a></li>
                    <li><a href="./comingsoon/index1.php">Ocean Freight</a></li>
                    <li><a href="map.html">Ground Shipping</a></li>
                                    </ul>
                                </li>
                                <li><a href="industries1.php">Industries</a></li>
                                <li><a href="blog1.php">Blog</a></li>
                                <li><a href="contact1.php">Contact</a></li>
                                                              
                                 <label id="wel">
                                    <?php
                                session_start();
                                 echo "Welcome ".$_SESSION['email'];
                             ?> </label></li>
                             
                             <li><ul class="dropdown">
                                    <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                               </ul> </li>
                           </ul>
                            
                        </nav>
                    </div>


                    <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

                </div>

            </div>
    </div>

    </header>



    <div class="site-blocks-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row align-items-center justify-content-center text-center">

                <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">


                    <h1 class="text-white font-weight-light mb-5 text-uppercase font-weight-bold">Worldwide Freight Services</h1>
                    <p><a href="services.html" class="btn btn-primary py-3 px-5 text-white">Get Started!</a></p>

                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row align-items-center no-gutters align-items-stretch overlap-section">
            <div class="col-md-4">
                <div class="feature-1 pricing h-100 text-center">
                    <div class="icon">
                        <span class="icon-dollar"></span>
                    </div>
                    <h2 class="my-4 heading">Best Prices</h2>
                    
                </div>
            </div>
            <div class="col-md-4">
                <div class="free-quote bg-dark h-100">
                    <h2 class="my-4 heading  text-center">Get Free Quote</h2>
                    <form method="post">
                        <div class="form-group">
                            <label for="fq_name">Name</label>
                            <input type="text" class="form-control btn-block" id="uname" name="uname" placeholder="Enter Name">
                        </div>
                        <div class="form-group mb-4">
                            <label for="fq_email">Email</label>
                            <input type="email" class="form-control btn-block" id="fq_email" name="fq_email" placeholder="Enter Email">
                        </div>
                        <div class="form-group">
                            <input type="submit" onclick="show_message();" class="btn btn-primary text-white py-2 px-4 btn-block" value="Get Quote">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-3 pricing h-100 text-center">
                    <div class="icon">
                        <span class="icon-phone"></span>
                    </div>
                    <h2 class="my-4 heading">24/7 Support</h2>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="site-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-7 text-center border-primary">
                    <h2 class="mb-0 text-primary">What We Offer</h2>
                    <p class="color-black-opacity-5"></p>
                </div>
            </div>
            <div class="row align-items-stretch">
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-travel"></span></div>
                        <div>
                            <h3>Air Freight</h3>
                            <p>Air freight logistics is the shipment of goods via a chartered or scheduled air carrier. Air freight is a popular choice for many companies as it ensures passage for their goods to anywhere in the world that an aircraft can fly to and land. 
                            </p>
                            <p class="mb-0"><a href="https://supremefreight.com/what-is-air-freight-logistics/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-sea-ship-with-containers"></span></div>
                        <div>
                            <h3>Ocean Freight</h3>
                            <p>Ocean freight is the method of transporting goods through the sea. It is an important part of cross-border trade that lets people move massive amounts of goods between countries.
                            </p>
                            <p class="mb-0"><a href="https://seller.alibaba.com/businessblogs/px6pr5bh-what-is-ocean-freight-a-complete-guide">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-frontal-truck"></span></div>
                        <div>
                            <h3>Ground Shipping</h3>
                            <p>Ground freight is a cheap freight transportation method and is generally used to transport large items that are not time-sensitive. shipping freight via ground requires an average transit time of three to 10 days, depending on the pickup and delivery locations. 
                            </p>
                            <p class="mb-0"><a href="https://www.freightcenter.com/ground-freight">Learn More</a></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="site-section block-13">
        <!-- <div class="container"></div> -->


        <div class="owl-carousel nonloop-block-13">
            <div>
                <a href="#" class="unit-1 text-center">
                    <img src="images/img_1.jpg" alt="Image" class="img-fluid">
                    <div class="unit-1-text">
                        <h3 class="unit-1-heading">Storage</h3>
                        <p class="px-5">The logistics chain is a complex process involving a series of stages which must run perfectly smoothly to ensure that the goods arrive at their destination fast and safely. One of those stages is storage, which plays an essential part in the distribution process.
                        </p>
                    </div>
                </a>
            </div>

            <div>
                <a href="#" class="unit-1 text-center">
                    <img src="images/img_2.jpg" alt="Image" class="img-fluid">
                    <div class="unit-1-text">
                        <h3 class="unit-1-heading">Air Transports</h3>
                        <p class="px-5">Air freight logistics is the shipment of goods via a chartered or scheduled air carrier. Air freight is a popular choice for many companies as it ensures passage for their goods to anywhere in the world that an aircraft can fly to and land. 
                        </p>
                    </div>
                </a>
            </div>

            <div>
                <a href="#" class="unit-1 text-center">
                    <img src="images/img_3.jpg" alt="Image" class="img-fluid">
                    <div class="unit-1-text">
                        <h3 class="unit-1-heading">Cargo Transports</h3>
                        <p class="px-5">Cargo is transported by air in specialized cargo aircraft and in the luggage compartments of passenger aircraft. 
                        </p>
                    </div>
                </a>
            </div>

            <div>
                <a href="#" class="unit-1 text-center">
                    <img src="images/img_4.jpg" alt="Image" class="img-fluid">
                    <div class="unit-1-text">
                        <h3 class="unit-1-heading">Cargo Ship</h3>
                        <p class="px-5">A cargo ship or freighter is a merchant ship that carries cargo, goods, and materials from one port to another. ... Cargo ships are usually specially designed for the task, often being equipped with cranes and other mechanisms to load and unload, and come in all sizes.
                        </p>
                    </div>
                </a>
            </div>

            <div>
                <a href="#" class="unit-1 text-center">
                    <img src="images/img_5.jpg" alt="Image" class="img-fluid">
                    <div class="unit-1-text">
                        <h3 class="unit-1-heading">Ware Housing</h3>
                        <p class="px-5">Warehouse management process is important to meet the most primary business objective, which is to keep the operations cost low as possible and maximize the profit margin.
                        </p>
                    </div>
                </a>
            </div>


        </div>
    </div>




    <div class="site-section bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-7 text-center border-primary">
                    <h2 class="font-weight-light text-primary">More Services</h2>
                    <p class="color-black-opacity-5">We Offer The Following Services</p>
                </div>
            </div>
            <div class="row align-items-stretch">
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-travel"></span></div>
                        <div>
                            <h3>Air Air Freight</h3>
                            <p>Air freight is another term for air cargo that is, the shipment of goods through an air carrier.
                            </p>
                            <p><a href="https://supremefreight.com/what-is-air-freight-logistics/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-sea-ship-with-containers"></span></div>
                        <div>
                            <h3>Ocean Freight</h3>
                            <p>Ocean freight, also called sea freight, is the movement of goods internationally by sea. Ocean freight is far and away the most popular option for shipping goods internationally.
                            </p>
                            <p><a href="https://seller.alibaba.com/businessblogs/px6pr5bh-what-is-ocean-freight-a-complete-guide">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-frontal-truck"></span></div>
                        <div>
                            <h3>Ground Shipping</h3>
                            <p>Ground freight is a cheap freight transportation method and is generally used to transport large items that are not time-sensitive. 
                            <p><a href="https://www.freightcenter.com/ground-freight">Learn More</a></p>
                        </div>
                    </div>
                </div>


                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-barn"></span></div>
                        <div>
                            <h3>Warehousing</h3>
                            <p>A WMS constitutes an internal system of the logistics companies, which is highly configurable to control and manage aspects of storage, distribution, others
                            </p>
                            <p><a href="https://mobisoftinfotech.com/resources/blog/warehouse-management-system-role-and-functions-in-logistics-chain/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-platform"></span></div>
                        <div>
                            <h3>Storage</h3>
                            <p>Storage plays a vital part in the supply chain given that it helps to guarantee good delivery times and reduce warehouse losses, making it possible to offer better services, to occupy a position ahead of competitors and, ultimately, to increase profits.
                            </p>
                            <p><a href="https://www.bilogistik.com/en/blog/importance-storage-logistics-chain/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-car"></span></div>
                        <div>
                            <h3>Delivery Van</h3>
                            <p>The process of delivering goods or services.  Supply chain management is concerned with the flow of materials and services, including delivery to the ultimate customer, as well as the associated flows of money and information. 
                            </p>
                            <p><a href="https://www.scm-portal.net/glossary/delivery.shtml">Learn More</a></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="site-blocks-cover overlay inner-page-cover" style="background-image: url(images/hero_bg_2.jpg); background-attachment: fixed;">
        <div class="container">
            <div class="row align-items-center justify-content-center text-center">

                <div class="col-md-7" data-aos="fade-up" data-aos-delay="400">
                    <a href="https://youtu.be/Pc0MDeOCjJw" class="play-single-big mb-4 d-inline-block popup-vimeo"><span class="icon-play"></span></a>
                    <h2 class="text-white font-weight-light mb-5 h1">View Our Services By Watching This Short Video</h2>

                </div>
            </div>
        </div>
    </div>

   
    <div class="site-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-7 text-center border-primary">
                    <h2 class="font-weight-light text-primary">Our Blog</h2>
                    <p class="color-black-opacity-5">See Our Daily News &amp; Updates</p>
                </div>
            </div>
            <div class="row mb-3 align-items-stretch">
                <div class="col-md-6 col-lg-6 mb-4 mb-lg-4">
                    <div class="h-entry">
                        <img src="images/blog_1.jpg" alt="Image" class="img-fluid">
                        <h2 class="font-size-regular"><a href="https://economictimes.indiatimes.com/topic/warehousing">Warehousing Packers</a></h2>
                        <div class="meta mb-4">by Theresa Winston <span class="mx-2">&bullet;</span> Jan 18, 2020 at 2:00 pm <span class="mx-2">&bullet;</span> <a href="https://economictimes.indiatimes.com/topic/warehousing">News</a></div>
                        <p>As a warehouse packer, sometimes called a picker, you are in charge of preparing packages for shipment from the warehouse. You retrieve the items needed on the invoice from the inventory, check that they are in good condition, wrap them securely, and pack them for shipping.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 mb-4 mb-lg-4">
                    <div class="h-entry">
                        <img src="images/blog_2.jpg" alt="Image" class="img-fluid">
                        <h2 class="font-size-regular"><a href="https://economictimes.indiatimes.com/topic/warehousing">Warehousing Your Packages</a></h2>
                        <div class="meta mb-4">by Theresa Winston <span class="mx-2">&bullet;</span> Jan 18, 2019 at 2:00 pm <span class="mx-2">&bullet;</span> <a href="https://economictimes.indiatimes.com/topic/warehousing">News</a></div>
                        <p>The packing process takes place in the warehouse and typically consists of choosing appropriate materials and an appropriate container to pack the products, weighing the package, and labeling it with the relevant invoice or packing slip.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="site-section border-top">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <h2 class="mb-5 text-black">Try Our Services</h2>
                    <p class="mb-0"><a href="#" onclick="topFunction()" id="myBtn" class="btn btn-primary py-3 px-5 text-white">Get Started</a></p>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Quick Links</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Products</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Follow Us</h2>
                            <a href="https://www.instagram.com/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                            <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4tZ2IifQ%3D%3D%22%7D" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                            <a href="https://www.facebook.com/" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                            <a href="https://www.linkedin.com/" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
                    <form action="#" method="post">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" id="sub" name="sub" aria-label="Enter Email" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary text-white " onclick="thank();" type="button" id="button-addon2">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row pt-5 mt-5 text-center">
                <div class="col-md-12">
                    <div class="border-top pt-5">
                        
                    </div>
                </div>

            </div>
        </div>
    </footer>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>

</body>

</html>