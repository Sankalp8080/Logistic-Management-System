
<html>
<head>
<script>
    function mypop() {
    alert("Response has been Recorded");
    window.location="contact.html";
}

function wrongpop() {
    alert("Something Went wrong!!!")
}
</script>
</head>
<?php
include ('connection.php'); 
$message=$_POST['message'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$emailid=$_POST['emailid'];
$subject=$_POST['subject'];

$sql ="insert into contact(firstname,lastname,email,subject,message) values('$fname','$lname','$emailid','$subject','$message')";
$result= mysqli_query($conn,$sql);

   
if($result)
   {
       echo"<script>mypop()</script>";
       
   }
   else
{
       echo"<script>alert('Something went wrong!!!')</script>";
    
}
   
?>
</html>