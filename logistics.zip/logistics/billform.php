<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <script type="text/javascript">
        var specialKeys = new Array();
        specialKeys.push(8); //Backspace
        function IsNumeric(e) {
            var keyCode = e.which ? e.which : e.keyCode
            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
            document.getElementById("error").style.display = ret ? "none" : "inline";
            return ret;
         }
         function redirect()
         {
          alert("Your order is place thank you");
          window.location="./index1.php";
         }
         function fillupcheck() {
           var fname= document.getElementById('formdata').fname.value;
           var email= document.getElementById('formdata').email.value;
           var address= document.getElementById('formdata').address.value;
           var city= document.getElementById('formdata').city.value;
           var state= document.getElementById('formdata').state.value;
           var zip= document.getElementById('formdata').zip.value;
           var cname= document.getElementById('formdata').cname.value;
           var ccnum= document.getElementById('formdata').ccnum.value;
           var expmonth= document.getElementById('formdata').expmonth.value;
            var expyear= document.getElementById('formdata').expyear.value;
             var cvv= document.getElementById('formdata').cvv.value;
             if(fname===""&&email===""&&address===""&&city===""&&state===""&&zip===""&&cname===""&&ccnum===""&&expmonth===""&&expyear===""&&cvv===""){
              alert("Please Fill up the details");
              return false;
             }

         }
    </script>
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #04AA6D;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>

</head>
<body>

<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="index1.php" id="formdata"  method="POST">
      
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="fname" placeholder="First name"required>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="example@example.com"required>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="address" name="address" placeholder="123,Santi nagar" required>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="Mumbai" required>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="Maharashtr" required>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="400055" required>
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="ABC PQR XYZ"required>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber"  placeholder="1111-2222-3333-4444"required >
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September"required>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018"required>
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352"  required>
              </div>
            </div>
          </div>
          
        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label>
        <input type="submit" onclick="redirect()" value="Continue to checkout" class="btn">
      </form>
    </div>
  </div>
  <div class="col-25">
    <div class="container">
<form method="post">
  <div>
    <label>Item Name:</label>
    <input type="text" name="txtItemname" id="txtItemname" required>
      </div>
      <div>
        <label>Item Quantity:</label>
        <input type="text" name="txtItemquantity"id="txtItemquantity" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;" required>
        <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
      </div>
      <div>
        <label>Item Weight:</label>
        <input type="text" name="txtItemweight" id="txtItemweight" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;"required >
        <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
      </div>
      <div>
        <label>Distance in Miles</label>
        <input type="text" name="txtenterdistance" id="txtenterdistance" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;" required>
        <span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
      </div>
  <div class="btnprev">
                        <button type="submit" name="submit"value="Next"  id="btnSubmit" class="next">Calculate</button>
                      </div>
                    </div>
</form>


      <?php
      ob_start();
      if(isset($_POST['submit']))
      {
      $txtItemname=$_POST['txtItemname'];
      $txtItemquantity=$_POST['txtItemquantity'];
      $txtItemweight=$_POST['txtItemweight'];
      $txtenterdistance=$_POST['txtenterdistance'];
      $total=((float)$txtenterdistance * 35 + $txtItemweight * 5+$txtItemquantity*10);
      
      echo"Item Name: ".$txtItemname."<br>";
      echo"Item Quantity: ".$txtItemquantity."<br>";
      echo "Item Weight: ".$txtItemweight."<br>";
      echo "Distance: ".$txtenterdistance."<br>";
      echo "Final Total: ".$total;
ob_clean();
}

      ?>
      
     
     
     
    </div>
  </div>
</div>

</body>
</html>