<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Form</title>

    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="./assets/plugins/owl.carousel/dist/css/owl.carousel.min.css">
    <link href="./assets/plugins/fullcalendar/css/fullcalendar.min.css" rel="stylesheet">
    <!-- Chartist -->
    <link rel="stylesheet" href="./assets/plugins/chartist/css/chartist.min.css">
       <!-- JS Grid -->
    <link rel="stylesheet" href="./assets/plugins/jsgrid/css/jsgrid.min.css">
    <link rel="stylesheet" href="./assets/plugins/jsgrid/css/jsgrid-theme.min.css">
    <!-- Footable -->
    <link rel="stylesheet" href="./assets/plugins/footable/css/footable.bootstrap.min.css">
    <!-- Bootgrid -->
    <link rel="stylesheet" href="./assets/plugins/jquery-bootgrid/dist/jquery.bootgrid.min.css">
    <!-- Datatable-->
    <link href="./assets/plugins/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

    <link href="./main/css/style.css" rel="stylesheet">
</head>