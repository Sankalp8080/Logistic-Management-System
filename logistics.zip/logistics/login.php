<?php
session_start();
$host  = "localhost";
$username = "root"; // For MYSQL the predifined username is root
$password = ""; // For MYSQL the predifined password is " "(blank)
$db="logic_test";
$conn = mysqli_connect($host,$username,$password,$db);

  
/*if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You have to log in first";
    header('location: login.html');
}*/
//$name = $_POST['username'];
$email = $_POST['emailid'];
$password = $_POST['pass'];
if(isset($_POST['login'])){
	$email = $_POST['emailid'];
	$password = $_POST['pass'];

	$query = mysqli_query($conn,"select * from registration where email ='$email' AND password ='$password'");
	$count = mysqli_num_rows($query);

	if($count >0){
			$_SESSION['email'] = $email;
			echo"<script>window.open('index1.php','_self')</script>";
	}
	else{
			      echo "<script>alert('Your username and password is wrong :(')</script>";
  echo "<script>window.open('login.html','_self')</script>";

	}
}
?>