<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Title -->
	<title>
		Billing Process
	</title>
	<!-- CSS Global Compulsory
    <link rel="stylesheet" href="./assets/css/bootstrap4.min.css" />
    <link rel="stylesheet" href="./assets/css/reset.css" />
    <link rel="stylesheet" href="./assets/css/lib.css" /> -->


	<!-- CSS -->
	<link rel="stylesheet" href="./assets/css/custom.css?v=1.0.7907.40018" />
	<link rel="stylesheet" href="./assets/css/style.css?v=1.0.7907.40018" />
	<link rel="stylesheet" href="./assets/css/other.css?v=1.0.7907.40018" />
	<style type="text/css">
		label {
			font-size: 25;
		}
	</style>
<script type="text/javascript">
	function SelectRedirect()
	{
		switch(document.getElementById('txtpayment').value)
{
case "COD(Cash on Delivery)":
window.location="";
break;

case "Online":
window.location="./billform.html";
break;
}
	}
</script>
</head>

<body>
	<?php include_once('inc/head.php'); ?>
	<div class="skin-blue sidebar-mini  pace-running pace-done" style="overflow-y: scroll">
		<div id="app">
			<div id="app">
				<div class="wrapper">
					<div class="content-wrapper" style="min-height: 791px;">
						<section class="content-header ">
							<main class="maincontent">

								<form action="formsubmit.php" method="POST"> 
									<div class="personaldetail address_box address_wrapper fl pdb30 mb30">
										<div class="tab_title">
											<h2>Basic Details</h2>
										</div>
										<hr />
										<div id="personalDetails">

											<div class="">
												<div class="form-group col-md-6 required">
													<label for="txtFirstName">First Name<span class="smred">&nbsp;</span></label>
													<input type="text" class="form-control" id="txtFirstName" name="txtFirstName" placeholder="" maxlength="50"	required>
												</div>
												<div class="form-group col-md-6">
													<label for="txtLastName">Last Name<span class="smred">&nbsp;</span></label>
													<input type="text" class="form-control" id="txtLastName" name="txtLastName" placeholder="" maxlength="50" required >
												</div>
											</div>



											<div class="clear"></div>
											<div class="col-lg-12 mt30">
												<h3 class="capital">Contact Details</h3>
											</div>
											<div class="per_mob">
												<div class="form-group col-md-6 required">
													<label for="txtMobileNo">Mobile No </label>
													<br />
													<input type="text" class="form-control" id="txtMobileNo" name="txtMobileNo" placeholder="" maxlength="10" required>
												</div>
											</div>
											<div class="col-lg-12 mt30">
												<h3 class="capital">Residence Details</h3>
											</div>
											<div class="">
												<div class="form-group col-md-12 ">
													<label for="txtSenderAddress">Sender Address</label>
													<textarea id="txtSenderAddress" name="txtSenderAddress" placeholder="Enter Sender Address" class="form-control" required></textarea>
												</div>
												<div class="form-group col-md-12 ">
													<label for="txtReceiverAddress">Receiver Name and Address</label>
													<textarea id="txtReceiverAddress" name="txtReceiverAddress" placeholder="Enter Receiver Name and Address" class="form-control" required></textarea>
												</div>
												<div class="form-group col-md-12 ">
													<label for="txtenterdistance">Enter Distance (Miles)</label>
													<input type="text" id="txtenterdistance" name="txtenterdistance" class="form-control" required></input>
												</div>
											</div>

											<div class="col-lg-12 mt30">
												<h3 class="capital">Item Details</h3>
											</div>
											<div class="">
												<div class="form-group col-md-12 ">
													<label for="txtItemname">Item name</label>
													<input type="text" id="txtItemname" name="txtItemname" class="form-control"required></input>
												</div>
												<div class="form-group col-md-12 ">
													<label for="txtItemquantity">Item Quantity</label>
													<input type="text"  id="txtItemquantity" name="txtItemquantity" class="form-control"required></input>
												</div>
												<div class="form-group col-md-12 ">
													<label for="txtItemweight">Item Weight (KG)</label>
													<input type="text"  id="txtItemweight" name="txtItemweight" class="form-control" required></input>
												</div>
											</div>

											<div class="clear"></div>
											<div class="col-lg-12 mt30">
												<h3 class="capital">Payment Method</h3>
											</div>
											<div class="">
												<div class="form-group col-md-12 ">
													<select class="form-control" name="txtpayment"onchange="SelectRedirect()" id="txtpayment">
														<option value="Select"  >Select</option>
														<option value="COD(Cash on Delivery)">COD(Cash on Delivery)</option>
														<option value="Online" >Online</option>
													</select>
												</div>
											</div>
											<div class="clear"></div>
											<div class="btnprev">
												<button type="submit" name="submit"value="Next" id="btnSubmit" class="next">Submit</button>
											</div>
											<div class="clear"></div>

											<div class="clear"></div>
										</div>
								</form>
							</main>

						</section>
						<section class="content"></section>
					</div>
				</div>
			</div>
		</div>
	</div>
	</form>

	</div>
</body>

</html>