<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Logistics</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

<style type="text/css">
      p{
        color: black;
      }
      #wel{
        color: white;
      }
    </style>

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    <script src="js/message.js"></script>
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-11 col-xl-2">
            <h1 class="mb-0"><a href="index1.php" class="text-white h2 mb-0">Logistics</a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

             
                            <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                                <li class="active"><a href="index1.php">Home</a></li>
                                <li><a href="about1.php">About Us</a></li>
                                <li class="has-children">
                                    <a href="services1.php">Services</a>
                                    <ul class="dropdown">
                                        <li><a href="./comingsoon/index1.php">Air Freight</a></li>
                    <li><a href="./comingsoon/index1.php">Ocean Freight</a></li>
                    <li><a href="map.html">Ground Shipping</a></li>
                                    </ul>
                                </li>
                                <li><a href="industries1.php">Industries</a></li>
                                <li><a href="blog1.php">Blog</a></li>
                                <li><a href="contact1.php">Contact</a></li>
                                                              
                                 <label id="wel">
                                    <?php
                                session_start();
                                 echo "Welcome ".$_SESSION['email'];
                             ?> </label></li>
                             
                             <li><ul class="dropdown">
                                    <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                               </ul> </li>
                           </ul>
            </nav>
          </div>


          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
            <h1 class="text-white font-weight-light text-uppercase font-weight-bold">Our Services</h1>
            <p class="breadcrumb-custom"><a href="index.html">Home</a> <span class="mx-2">&gt;</span> <span>Services</span></p>
          </div>
        </div>
      </div>
    </div>  

    

    <div class="site-section bg-light">
      <div class="container">
                    <div class="row align-items-stretch">
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-travel"></span></div>
                        <div>
                            <h3>Air Air Freight</h3>
                            <p>Air freight is another term for air cargo that is, the shipment of goods through an air carrier.
                            </p>
                            <p><a href="https://supremefreight.com/what-is-air-freight-logistics/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-sea-ship-with-containers"></span></div>
                        <div>
                            <h3>Ocean Freight</h3>
                            <p>Ocean freight, also called sea freight, is the movement of goods internationally by sea. Ocean freight is far and away the most popular option for shipping goods internationally.
                            </p>
                            <p><a href="https://seller.alibaba.com/businessblogs/px6pr5bh-what-is-ocean-freight-a-complete-guide">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-frontal-truck"></span></div>
                        <div>
                            <h3>Ground Shipping</h3>
                            <p>Ground freight is a cheap freight transportation method and is generally used to transport large items that are not time-sensitive. 
                            <p><a href="https://www.freightcenter.com/ground-freight">Learn More</a></p>
                        </div>
                    </div>
                </div>


                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-barn"></span></div>
                        <div>
                            <h3>Warehousing</h3>
                            <p>A WMS constitutes an internal system of the logistics companies, which is highly configurable to control and manage aspects of storage, distribution, others
                            </p>
                            <p><a href="https://mobisoftinfotech.com/resources/blog/warehouse-management-system-role-and-functions-in-logistics-chain/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-platform"></span></div>
                        <div>
                            <h3>Storage</h3>
                            <p>Storage plays a vital part in the supply chain given that it helps to guarantee good delivery times and reduce warehouse losses, making it possible to offer better services, to occupy a position ahead of competitors and, ultimately, to increase profits.
                            </p>
                            <p><a href="https://www.bilogistik.com/en/blog/importance-storage-logistics-chain/">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 mb-4 mb-lg-4">
                    <div class="unit-4 d-flex">
                        <div class="unit-4-icon mr-4"><span class="text-primary flaticon-car"></span></div>
                        <div>
                            <h3>Delivery Van</h3>
                            <p>The process of delivering goods or services.  Supply chain management is concerned with the flow of materials and services, including delivery to the ultimate customer, as well as the associated flows of money and information. 
                            </p>
                            <p><a href="https://www.scm-portal.net/glossary/delivery.shtml">Learn More</a></p>
                        </div>
                    </div>
                </div>

            </div>
      </div>
    </div>
    
   
    
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Quick Links</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Products</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Features</h2>
                            <ul class="list-unstyled">
                                <li><a href="about1.php">About Us</a></li>
                                <li><a href="services1.php">Services</a></li>
                                <li><a href="contact1.php">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h2 class="footer-heading mb-4">Follow Us</h2>
                            <a href="https://www.instagram.com/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                            <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4tZ2IifQ%3D%3D%22%7D" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                            <a href="https://www.facebook.com/" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                            <a href="https://www.linkedin.com/" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
                    <form action="#" method="post">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" id="sub" name="sub" aria-label="Enter Email" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary text-white " onclick="thank();" type="button" id="button-addon2">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row pt-5 mt-5 text-center">
                <div class="col-md-12">
                    <div class="border-top pt-5">
                        
                    </div>
                </div>

            </div>
        </div>
    </footer>

  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>